public class QuickCrab extends CrabCritter {
    
}