import info.gridworld.actor.Actor;
import info.gridworld.grid.Location;
import info.gridworld.grid.Grid;
import java.util.ArrayList;

public class ChameleonKid extends ChameleonCritter {

    public ArrayList<Actor> getActors()
    {
        ArrayList<Actor> actors = new ArrayList<Actor>();
        Location loc = getLocation();
        Grid gr = getGrid();
        loc = loc.getAdjacentLocation(Location.AHEAD);
        if (gr.isValid(loc)) {
            if (gr.get(loc) != null) {
                Actor act = getGrid().get(loc);
                actors.add(act);
            }
        }
        loc = loc.getAdjacentLocation(Location.HALF_CIRCLE);
        if (gr.isValid(loc)) {
            if (gr.get(loc) != null) {
                Actor act = getGrid().get(loc);
                actors.add(act);
            }
        }
        return actors;
    }
}